import React from "react"

const Home = () => {

    return(
        <div className="formContainer">

        </div>
    )
};

export default Home;